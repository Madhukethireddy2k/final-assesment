package com.asessment.exam.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Inventory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	private String prodName;
	private String prodDesc;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProdDesc() {
		return prodDesc;
	}
	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}
	
	public Inventory(long id, String prodName, String prodDesc) {
		super();
		this.id = id;
		this.prodName = prodName;
		this.prodDesc = prodDesc;
	}
	
	public Inventory() {
		super();
	}
	
	@Override
	public String toString() {
		return "Inventory [id=" + id + ", prodName=" + prodName + ", prodDesc=" + prodDesc + "]";
	}
	
	
	
	
	
	

}
