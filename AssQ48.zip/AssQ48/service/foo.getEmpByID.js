const { json } = require('body-parser');

module.exports.getEmpByID=async(req,res,next)=>{
    var employees=require('./employees')
    const obj=req.params;
    console.log(obj.id);
    var EmployeeID=obj.id;
    var employee=employees[EmployeeID]
    console.log(employee);
    res.send({employee});
}