module.exports.getEmployees=async(req,res,next)=>{
    var employees=require('./employees')
    const obj=req.body;
    console.log(obj);
    res.send({employees});
}