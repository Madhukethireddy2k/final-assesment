var employees=[        {
    "EmpID": "0",
    "EmpName": "Hari",
    "Role": "Admin",
    
},
{
    "EmpID": "1",
    "EmpName": "Kiran",
    "Role": "User",
    
},
{
    "EmpID": "2",
    "EmpName": "Tharun",
    "Role": "Developer",
    
}
];
module.exports=employees;