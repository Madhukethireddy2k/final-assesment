const { Router }=require("express");
const router=new Router();

const Emp=require("../service/foo.getEmployees");
const Empid=require("../service/foo.getEmpByID");
router.get("/",Emp.getEmployees);
router.get("/:id",Empid.getEmpByID);
module.exports=router;